//package com.projetopi.tlgne.controllers;
//
//
//import com.projetopi.tlgne.entities.DetalhesVenda;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/detalhesVendas")
//public class DetalhesVendaController {
//
//    @Autowired
//    private DetalhesVenda detalhesVenda;
//
//    //Get de lista de detalhes venda
//}
